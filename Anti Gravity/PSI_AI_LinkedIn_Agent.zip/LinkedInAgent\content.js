// LinkedIn AI Recruiter - Content Script

let isScraping = false;
let scrapeConfig = null;

if (typeof window.hasLinkedInScraper === 'undefined') {
  window.hasLinkedInScraper = true;

  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "startScraping") {
      isScraping = true;
      scrapeConfig = request.config;
      sendResponse({ status: "started" });
      startScrapingLoop();
    } else if (request.action === "stopScraping") {
      isScraping = false;
      sendResponse({ status: "stopped" });
    }
    return true;
  });
}

function sendLog(text) {
  chrome.runtime.sendMessage({ action: 'log_from_content', text: text });
}

async function startScrapingLoop() {
  if (!isScraping) return;

  sendLog("Waiting 5 seconds for page load...");
  for (let i = 0; i < 5; i++) {
    if (!isScraping) return;
    await sleep(1000);
  }

  sendLog("Checking DOM for true search results...");
  let foundRealResults = false;
  for (let i = 0; i < 20; i++) {
    if (!isScraping) return;
    
    // Check if the skeleton loading animation is gone
    const isSkeleton = document.querySelector('.scaffold-layout__list-skeleton, .search-results__skeleton');
    
    // Look for actual candidate card wrappers
    const hasCard = document.querySelector('.reusable-search__result-container, .entity-result__item, .search-result__wrapper, .search-entity');
    const emptyState = document.querySelector('.search-reusable-search-no-results, .artdeco-empty-state[class*="no-results"], h2.artdeco-empty-state__headline, img.artdeco-empty-state__image');
    
    if (!isSkeleton && (hasCard || emptyState)) {
      foundRealResults = true;
      break;
    }
    
    await sleep(1000);
  }
  
  if (!isScraping) return;
  
  if (!foundRealResults) {
    sendLog("Warning: Search results took longer than 20 seconds to load, or the page structure is severely broken. Attempting extraction anyway...");
  }

  sendLog("Auto-scrolling to load all results...");
  await autoScroll();
  if (!isScraping) return;
  
  // Verify if LinkedIn actually threw a 0 results empty state page
  const emptyState = document.querySelector('.search-reusable-search-no-results, .artdeco-empty-state[class*="no-results"], h2.artdeco-empty-state__headline, img.artdeco-empty-state__image');
  if (emptyState) {
    sendLog("ERROR: LinkedIn returned exactly 0 results for this specific search combination! Try modifying your Job Role text.");
    isScraping = false;
    chrome.runtime.sendMessage({ type: 'stopped' });
    return;
  }
  
  sendLog("Parsing dynamic DOM tree for candidates...");
  const profiles = extractProfiles();
  sendLog(`=> Found ${profiles.length} unique candidates on this page.`);

  if (profiles.length === 0) {
    sendLog("ERROR: Could not fetch candidate data. Even the pure DOM traversal failed. Stopping automation.");
    isScraping = false;
    chrome.runtime.sendMessage({ type: 'stopped' });
    return;
  }

  for (const profile of profiles) {
    if (!isScraping) break; 
    
    chrome.runtime.sendMessage({ action: 'candidateFound', candidate: profile });
    
    for (let w = 0; w < 4; w++) { // Wait 2s total, checking interrupt every 500ms
      if (!isScraping) break;
      await sleep(500);
    }
  }

  if (isScraping) {
    sendLog("Locating the 'Next' page button...");
    
    let nextBtn = document.querySelector('.artdeco-pagination__button--next, [aria-label="Next"], [aria-label="Next page"]');
    
    if (!nextBtn) {
      const buttons = Array.from(document.querySelectorAll('button, a'));
      nextBtn = buttons.find(b => b.innerText && b.innerText.trim().startsWith('Next'));
    }

    if (nextBtn && !nextBtn.disabled && !nextBtn.classList.contains('disabled')) {
      sendLog("Clicking 'Next' page...");
      chrome.runtime.sendMessage({ action: 'fetchNextPage' });
      nextBtn.scrollIntoView({ behavior: 'smooth', block: 'center' });
      for (let w = 0; w < 3; w++) {
        if (!isScraping) return;
        await sleep(500);
      }
      if (!isScraping) return;
      nextBtn.click();
      
      let timerWait = 6000;
      let ticks = 0;
      let waitInterval = setInterval(() => {
        if (!isScraping) clearInterval(waitInterval);
        ticks += 500;
        if (ticks >= timerWait && isScraping) {
          clearInterval(waitInterval);
          startScrapingLoop();
        }
      }, 500);
    } else {
      isScraping = false;
      sendLog("Finished! No 'Next' button found, or it is disabled. Search complete.");
      chrome.runtime.sendMessage({ type: 'stopped' });
    }
  }
}

function extractProfiles() {
  const candidates = [];
  try {
    const main = document.querySelector('main, #main, .scaffold-layout__main') || document.body;
    
    const profileLinks = Array.from(main.querySelectorAll('a[href*="/in/"]'));
    if (profileLinks.length === 0) {
       sendLog("No links containing '/in/' were found in the main content area.");
       return [];
    }

    const uniqueUrls = [...new Set(profileLinks.map(a => a.href.split('?')[0]))];
    
    for (const url of uniqueUrls) {
      if (url.toLowerCase().includes('/in/linkedin') || url.endsWith('/in/')) continue;
      
      const anchorsForUrl = profileLinks.filter(a => a.href.split('?')[0] === url);
      
      let nameAnchor = anchorsForUrl.find(a => a.innerText.trim().length > 2 && !a.querySelector('img')) 
                       || anchorsForUrl.find(a => a.innerText.trim().length > 2);
      
      if (!nameAnchor) continue;
      
      let name = nameAnchor.innerText.trim();
      if (name.includes('\n')) name = name.split('\n')[0]; 
      
      const hiddenSpan = nameAnchor.querySelector('span[aria-hidden="true"]');
      if (hiddenSpan && hiddenSpan.innerText.trim().length > 2) {
        let cleanName = hiddenSpan.innerText.trim();
        if (!cleanName.toLowerCase().includes("view ") && !cleanName.toLowerCase().includes("profile")) {
          name = cleanName;
        }
      }
      
      if (name.toLowerCase() === "linkedin member" || name.length === 0) continue;

      let card = nameAnchor.closest('.reusable-search__result-container, .entity-result__item, .search-result__wrapper, .search-entity, li');
      
      if (!card) {
        let domNode = nameAnchor;
        for (let i = 0; i < 10; i++) {
          if (domNode.parentElement) {
            domNode = domNode.parentElement;
            if (domNode.querySelector('.entity-result__primary-subtitle') && domNode.querySelector('.entity-result__secondary-subtitle')) {
              card = domNode;
              break;
            } else if (domNode.tagName === 'LI' || domNode.classList.contains('reusable-search__result-container')) {
              card = domNode;
              break;
            }
          }
        }
      }
      
      if (!card) {
        card = nameAnchor.parentElement.parentElement.parentElement;
      }
      
      let headline = "Headline Not Found";
      let location = "Unknown Location";
      let about = "";
      
      if (card) {
        // LinkedIn randomly changes CSS classes or fully removes them during A/B split testing (e.g. your account).
        // Solution: A 100% Class-Agnostic Visual Hierarchy Parser based entirely on visual position!
        
        let rawText = card.innerText || "";
        let lines = rawText.split('\n').map(l => l.trim()).filter(l => l.length > 0);
        
        // Find which line visually contains the person's name
        let nameIndex = lines.findIndex(l => l.includes(name) || name.includes(l.split(' ')[0]));
        if (nameIndex === -1) nameIndex = 0; // fallback to very top
        
        // Filter out all the junk buttons and generic LinkedIn metadata 
        let validLines = lines.slice(nameIndex + 1).filter(l => 
          !l.includes('•') && 
          !l.toLowerCase().includes('degree connection') && 
          !l.toLowerCase().startsWith('view ') && 
          !l.match(/^(1st|2nd|3rd\+)$/i) &&
          !l.match(/^(Connect|Follow|Message|Save|Send|Pending)$/i) &&
          !l.toLowerCase().includes('mutual connection') &&
          !l.toLowerCase().includes(' followers') &&
          !l.toLowerCase().includes(' premium') &&
          !l.toLowerCase().includes(' shared connection')
        );

        // Visual Law of LinkedIn Search Cards:
        // Position 1 (validLines[0]) is ALWAYS the Headline.
        // Position 2 (validLines[1]) is ALWAYS the Location.
        // Position 3 (validLines[2]) is ALWAYS the Summary or Past/Current Role snippet.

        if (validLines.length > 0) headline = validLines[0].replace(/\n+/g, ' | ');
        if (validLines.length > 1) location = validLines[1].replace(/\n+/g, ', ');
        if (validLines.length > 2) about = validLines.slice(2, 4).join(' | ').replace(/\n+/g, ' | ');
      }
      
      candidates.push({ name, link: url, headline, location, about });
    }
  } catch (err) {
    sendLog("Exception during extraction: " + err.message);
  }
  
  return candidates;
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function autoScroll() {
  await new Promise((resolve) => {
    let totalHeight = 0;
    const distance = 250;
    const timer = setInterval(() => {
      if (!isScraping) {
        clearInterval(timer);
        resolve();
        return;
      }
      const scrollHeight = document.body.scrollHeight;
      window.scrollBy(0, distance);
      totalHeight += distance;

      if (totalHeight >= scrollHeight - window.innerHeight || totalHeight > 8000) {
        clearInterval(timer);
        resolve();
      }
    }, 200);
  });
}
