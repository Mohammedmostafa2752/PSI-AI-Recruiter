// LinkedIn AI Recruiter - Background Script

let isRunning = false;
let config = {};
let targetTabId = null;

// Persistent State arrays
let collectedCandidates = [];
let instanceLogs = [];
let lastConfig = null;
let currentPage = 1;
let totalProcessedCount = 0;

// Load state from Chrome Storage (Service Worker safe)
async function loadState() {
  const data = await chrome.storage.local.get(['collectedCandidates', 'instanceLogs', 'lastConfig', 'currentPage', 'isRunning', 'config', 'totalProcessedCount']);
  collectedCandidates = data.collectedCandidates || [];
  instanceLogs = data.instanceLogs || [];
  lastConfig = data.lastConfig || null;
  currentPage = data.currentPage || 1;
  isRunning = data.isRunning || false;
  config = data.config || {};
  totalProcessedCount = data.totalProcessedCount || 0;
}

// Save state to Chrome Storage
function saveState() {
  chrome.storage.local.set({
    collectedCandidates,
    instanceLogs,
    lastConfig,
    currentPage,
    isRunning,
    config,
    totalProcessedCount
  });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getInitialState') {
    // Because it's async, we handle it inside an IIFE
    (async () => {
      await loadState();
      sendResponse({ 
        isRunning, 
        logs: instanceLogs,
        count: collectedCandidates.length 
      });
    })();
    return true; // Keep message channel open for async response
  } else if (request.action === 'startSearch') {
    startProcess(request.payload);
    sendResponse({ status: 'started' });
  } else if (request.action === 'stopSearch') {
    stopProcess();
    sendResponse({ status: 'stopped' });
  } else if (request.action === 'candidateFound') {
    (async () => {
      totalProcessedCount++;
      
      let candidateLabel = request.candidate.name !== "Indeed Candidate" ? request.candidate.name : request.candidate.headline.substring(0, 35);
      sendLog(`[AI] Evaluating #${totalProcessedCount}: ${candidateLabel}...`);
      
      const result = await evaluateCandidateWithAI(request.candidate, config);
      if (result) {
        request.candidate.score = result.score;
        request.candidate.decision = result.decision;
        request.candidate.reasoning = result.reasoning;
        if (result.extracted_location && result.extracted_location !== "Unknown") {
            request.candidate.location = result.extracted_location;
        }
        
        if (result.decision === 'Fit' && result.score >= 80) {
          collectedCandidates.push(request.candidate);
          saveState();
          sendLog(`⭐ MATCH! [Score ${result.score}/100]: ${candidateLabel} FIT!`);
        } else {
          sendLog(`❌ REJECTED [Score ${result.score}/100]: ${result.reasoning}`);
        }
      }
    })();
    return true;
  } else if (request.action === 'fetchNextPage') {
    (async () => {
      await loadState();
      currentPage++;
      saveState();
      sendLog(`Navigating to search page ${currentPage}...`);
    })();
  } else if (request.action === 'downloadCsv') {
    (async () => {
      await loadState();
      generateAndDownloadCsv();
      sendResponse({ count: collectedCandidates.length });
    })();
    return true;
  } else if (request.action === 'log_from_content') {
    sendLog(`[Scraper] ${request.text}`);
  } else if (request.action === 'clearLogs') {
    instanceLogs = [];
    saveState();
  }
  return true; 
});

async function startProcess(payload) {
  await loadState();
  
  let isResume = payload.isResume === true;

  if (!isResume) {
    collectedCandidates = [];
    instanceLogs = [];
    currentPage = 1;
    totalProcessedCount = 0; // Wipe the absolute metric counter
    lastConfig = { role: payload.role, requirements: payload.req, country: payload.country };
  }
  
  config = payload;
  isRunning = true;
  saveState(); // Commit to DB instantly
  
  if (isResume && currentPage > 1) {
    sendLog(`Resuming AI Search exactly from Page ${currentPage}...`);
  } else {
    sendLog(`Starting AI Search for: ${config.role}`);
  }

  let searchUrl = '';

  if (config.platform === 'indeed') {
    let exactRole = config.role.trim();
    let location = config.country !== 'Anywhere' ? config.country : '';
    searchUrl = `https://resumes.indeed.com/search?q=${encodeURIComponent(exactRole)}&l=${encodeURIComponent(location)}`;
    if (currentPage > 1) {
      searchUrl += `&start=${(currentPage - 1) * 50}`;
    }
  } else {
    const geoMap = {
      'UAE': '104305776',
      'KSA': '100459316',
      'EGY': '106155605',
      'QAT': '104514075',
      'IND': '102713980',
      'USA': '103644278',
      'UK': '101165590'
    };

    let exactRole = config.role.trim();
    if (config.country && !geoMap[config.country] && config.country !== 'Anywhere') {
      exactRole += ` "${config.country.trim()}"`;
    }
    
    const searchQuery = encodeURIComponent(exactRole);
    searchUrl = `https://www.linkedin.com/search/results/people/?keywords=${searchQuery}&origin=CLUSTER_EXPANSION`;

    if (geoMap[config.country]) {
      searchUrl += `&geoUrn=%5B%22${geoMap[config.country]}%22%5D`;
    }
    if (currentPage > 1) {
      searchUrl += `&page=${currentPage}`;
    }
  }

  // Create the tab actively so the user can pass Cloudflare or Login checks
  chrome.tabs.create({ url: searchUrl, active: true }, (tab) => {
    targetTabId = tab.id;
    
    chrome.tabs.onUpdated.addListener(function listener(tabId, info) {
      if (tabId === targetTabId && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        sendLog("Target page attached. Injecting scraper protocols...");
        
        chrome.scripting.executeScript({
          target: { tabId: targetTabId },
          files: ['content.js']
        }).then(() => {
          setTimeout(() => {
            chrome.tabs.sendMessage(targetTabId, { action: "startScraping", config: config }, (res) => {
              if (chrome.runtime.lastError) {
                sendLog(`Warning: Scraper tab detached. Please restart.`);
              }
            });
          }, 2000);
        }).catch(err => {
          sendLog(`Injection Error: ${err.message}`);
          stopProcess();
        });
      }
    });
  });
}

function stopProcess() {
  isRunning = false;
  saveState();
  sendLog('Process paused by user.');
  chrome.runtime.sendMessage({ type: 'stopped' });
  if (targetTabId) {
    chrome.tabs.sendMessage(targetTabId, { action: "stopScraping" }, () => {});
  }
}

// ----------------------------------------------------
// AI Evaluation
// ----------------------------------------------------
async function evaluateCandidateWithAI(candidate, config) {
  const prompt = `
You are an expert, meticulous AI recruiter. Evaluate this candidate based strictly on the user criteria.
Job Title: ${config.role}
Job Requirements: ${config.requirements}
Target Country: ${config.country && config.country !== 'Anywhere' ? config.country : 'None'}

Candidate Profile:
Name: ${candidate.name}
Headline: ${candidate.headline}
Location: ${candidate.location}
About: ${candidate.about}

CRITICAL INSTRUCTIONS:
1. FLEXIBLE ROLE MATCHING: Do not demand exact keyword matches for Job Titles! Focus on the core function. (e.g., 'CRM Executive' is functionally equivalent to 'CRM Analyst').
2. EDUCATION INTELLIGENCE: Synthesize educational degrees intelligently. Accept abbreviations like "BA", "B.Tech", "BS" as Bachelor degrees.
3. LOCATION EXTRACTION & STRICTNESS: First, determine the candidate's actual city and country from their Profile. Then, if the "Job Requirements" specifically demand certain cities (e.g., 'Dubai or Abu Dhabi'), you MUST forcefully reject (Score < 80) candidates in other cities (e.g., 'Ajman', 'Sharjah'), even if they are in the same country.
4. JOB REQUIREMENTS: Base your evaluation on the actual functional skills and years of experience requested.
5. SCORING: 
   - 80-100: Great fit. Strong match on core function, education, and STRICT location fit.
   - Below 80: Clear mismatch in core function or major deficiencies (like wrong city).
6. Respond ONLY in valid JSON format with exactly four fields:
- "extracted_location": The candidate's actual city/country based on the text. If absolutely not mentioned, output EXACTLY "Unknown". DO NOT guess.
- "score": A number out of 100 representing how well they match.
- "decision": "Fit" or "No Fit"
- "reasoning": A single strict sentence explaining your decision based on the criteria.
`;

  try {
    const result = await callOpenAI(prompt, config.key);
    return result;
  } catch (err) {
    sendLog(`AI Connection Error: ${err.message}`);
    return { score: 0, decision: "Error", reasoning: err.message };
  }
}



async function callOpenAI(prompt, apiKey) {
  const url = `https://api.openai.com/v1/chat/completions`;
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
    body: JSON.stringify({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" }
    })
  });
  const data = await response.json();
  if (data.error) throw new Error(data.error.message);
  
  const textVal = data.choices[0].message.content;
  return JSON.parse(textVal);
}

// ----------------------------------------------------
// Data Handling & CSV Export
// ----------------------------------------------------
async function handleCandidate(candidate) {
  await loadState(); // Ensure we have latest if worker slept
  if (!isRunning) return;

  try {
    const assessment = await evaluateCandidateWithAI(candidate, config);
    sendLog(`[${assessment.score}/100] ${candidate.name} -> ${assessment.decision}`);
    
    candidate.score = assessment.score;
    candidate.decision = assessment.decision;
    candidate.reasoning = assessment.reasoning;

    collectedCandidates.push(candidate);
    saveState(); // Commit candidate instantly!
  } catch(e) {
    sendLog(`Failed to parse ${candidate.name}.`);
  }
}

function generateAndDownloadCsv() {
  if (collectedCandidates.length === 0) {
    sendLog("No prospects collected yet. Waiting for targets...");
    return;
  }

  const headers = ["Name", "Profile Link", "Headline", "Location", "AI Match Score", "AI Decision", "AI Reasoning"];
  const rows = collectedCandidates.map(c => [
    `"${c.name.replace(/"/g, '""')}"`,
    `"${c.link.replace(/"/g, '""')}"`,
    `"${c.headline.replace(/"/g, '""')}"`,
    `"${c.location.replace(/"/g, '""')}"`,
    c.score,
    `"${c.decision.replace(/"/g, '""')}"`,
    `"${c.reasoning.replace(/"/g, '""')}"`
  ]);

  const csvContent = [headers.join(","), ...rows.map(e => e.join(","))].join("\n");
  
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const reader = new FileReader();

  reader.onload = function() {
    chrome.downloads.download({
      url: reader.result,
      filename: `PSI_AI_Target_${(config.role || 'Export').replace(/ /g, '_')}_${new Date().getTime()}.csv`,
      saveAs: true
    });
  };
  reader.readAsDataURL(blob);
}

function sendLog(text) {
  console.log(text);
  instanceLogs.push(text);
  if (instanceLogs.length > 50) instanceLogs.shift();
  saveState(); // Save logs so popup always has them
  chrome.runtime.sendMessage({ type: 'log', text });
}
